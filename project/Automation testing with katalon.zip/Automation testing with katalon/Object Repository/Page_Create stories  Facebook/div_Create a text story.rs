<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Create a text story</name>
   <tag></tag>
   <elementGuidId>52d77526-0315-47a3-9e5f-a9e4b5d3c7cd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='mount_0_0_li']/div/div/div/div[5]/div/div/div[3]/div[2]/div[2]/div/div/div/div/div[2]/div/div/div/div[3]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.x1i10hfl.x1qjc9v5.xjbqb8w.xjqpnuy.xa49m3k.xqeqjp1.x2hbi6w.x13fuv20.xu3j5b3.x1q0q8m5.x26u7qi.x972fbf.xcfux6l.x1qhh985.xm0m39n.x9f619.x1ypdohk.xdl72j9.x2lah0s.xe8uvvx.xdj266r.x11i5rnm.xat24cr.x1mh8g0r.x2lwn1j.xeuugli.xexx8yu.x4uap5.x18d9i69.xkhd6sd.x1n2onr6.x16tdsg8.x1hl2dhg.xggy1nq.x1ja2u2z.x1t137rt.x1o1ewxj.x3x9cwd.x1e5q0jg.x13rtm0m.x3nfvp2.x1q0g3np.x87ps6o.x1lku1pv.x1a2a7pz.x1bhdf0j > div.html-div.xdj266r.x11i5rnm.xat24cr.x1mh8g0r.x4uap5.x18d9i69.xkhd6sd.xqtp20y.x1n2onr6.xh8yej3.xbobb8a > div.html-div.x1qjc9v5.x1q0q8m5.x1qhh985.xu3j5b3.xcfux6l.x26u7qi.xm0m39n.x13fuv20.x972fbf.x1ey2m1c.x9f619.x78zum5.xdt5ytf.x1iyjqo2.xs83m0k.xds687c.x17qophe.x1qughib.xat24cr.x11i5rnm.x1mh8g0r.xdj266r.x2lwn1j.xeuugli.x18d9i69.x4uap5.xkhd6sd.xexx8yu.x10l6tqk.x13vifvy.x1ja2u2z > div.x6s0dn4.x1ey2m1c.x78zum5.xds687c.xdt5ytf.xl56j7k.x10l6tqk.x17qophe.x13vifvy > div.x9f619.x14ctfv.x78zum5.x67ct29.x117nqv4.xl56j7k.x5ib6vp.xc73u3c.x1n2onr6.x2b8uid.xh8yej3</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;Create a text story&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>122b5321-8e8b-4337-8702-66226cabcdcd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>x9f619 x14ctfv x78zum5 x67ct29 x117nqv4 xl56j7k x5ib6vp xc73u3c x1n2onr6 x2b8uid xh8yej3</value>
      <webElementGuid>8c9b8779-ae38-41e4-9acf-5bc5f4516ce4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Create a text story</value>
      <webElementGuid>78714360-bb3c-4105-a9f1-52fc137b4054</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mount_0_0_li&quot;)/div[1]/div[1]/div[@class=&quot;x9f619 x1n2onr6 x1ja2u2z&quot;]/div[@class=&quot;__fb-light-mode x1n2onr6 x1vjfegm&quot;]/div[@class=&quot;x9f619 x1n2onr6 x1ja2u2z&quot;]/div[@class=&quot;x78zum5 xdt5ytf xippug5 xg6iff7 x1n2onr6&quot;]/div[@class=&quot;x78zum5 xdt5ytf xg6iff7 x1n2onr6 x1ja2u2z x443n21&quot;]/div[@class=&quot;x9f619 x2lah0s x1nhvcw1 x1qjc9v5 xozqiw3 x1q0g3np x78zum5 x1iyjqo2 x1t2pt76 x1n2onr6 x1ja2u2z&quot;]/div[@class=&quot;x9f619 x1n2onr6 x1ja2u2z xdt5ytf x193iq5w xeuugli x1r8uery x1iyjqo2 xs83m0k x78zum5 x1t2pt76&quot;]/div[@class=&quot;x78zum5 xdt5ytf x1iyjqo2 x1t2pt76 xeuugli x1n2onr6 x1ja2u2z&quot;]/div[@class=&quot;x1qjc9v5 x78zum5 xl56j7k x193iq5w x1t2pt76&quot;]/div[@class=&quot;x6s0dn4 x78zum5 xdt5ytf x193iq5w x1t2pt76 xh8yej3 xl56j7k&quot;]/div[@class=&quot;x78zum5 x1qughib xh8yej3&quot;]/div[@class=&quot;x1i10hfl x1qjc9v5 xjbqb8w xjqpnuy xa49m3k xqeqjp1 x2hbi6w x13fuv20 xu3j5b3 x1q0q8m5 x26u7qi x972fbf xcfux6l x1qhh985 xm0m39n x9f619 x1ypdohk xdl72j9 x2lah0s xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r x2lwn1j xeuugli xexx8yu x4uap5 x18d9i69 xkhd6sd x1n2onr6 x16tdsg8 x1hl2dhg xggy1nq x1ja2u2z x1t137rt x1o1ewxj x3x9cwd x1e5q0jg x13rtm0m x3nfvp2 x1q0g3np x87ps6o x1lku1pv x1a2a7pz x1bhdf0j&quot;]/div[@class=&quot;html-div xdj266r x11i5rnm xat24cr x1mh8g0r x4uap5 x18d9i69 xkhd6sd xqtp20y x1n2onr6 xh8yej3 xbobb8a&quot;]/div[@class=&quot;html-div x1qjc9v5 x1q0q8m5 x1qhh985 xu3j5b3 xcfux6l x26u7qi xm0m39n x13fuv20 x972fbf x1ey2m1c x9f619 x78zum5 xdt5ytf x1iyjqo2 xs83m0k xds687c x17qophe x1qughib xat24cr x11i5rnm x1mh8g0r xdj266r x2lwn1j xeuugli x18d9i69 x4uap5 xkhd6sd xexx8yu x10l6tqk x13vifvy x1ja2u2z&quot;]/div[@class=&quot;x6s0dn4 x1ey2m1c x78zum5 xds687c xdt5ytf xl56j7k x10l6tqk x17qophe x13vifvy&quot;]/div[@class=&quot;x9f619 x14ctfv x78zum5 x67ct29 x117nqv4 xl56j7k x5ib6vp xc73u3c x1n2onr6 x2b8uid xh8yej3&quot;]</value>
      <webElementGuid>43ed4589-dfec-4c7c-bc22-da968ec75df1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='mount_0_0_li']/div/div/div/div[5]/div/div/div[3]/div[2]/div[2]/div/div/div/div/div[2]/div/div/div/div[3]</value>
      <webElementGuid>8c31bf30-888b-4aad-8b3f-314e54c9b20f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Create a photo story'])[1]/following::div[10]</value>
      <webElementGuid>369f5a88-b95a-4c09-b0c9-ca46f84bda9b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Korupolu Likitha'])[2]/following::div[29]</value>
      <webElementGuid>aa81846f-30cd-4b0c-8bdc-e91a0af9d14e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Create a text story']/parent::*</value>
      <webElementGuid>99e6d283-5815-4afe-84e7-62e0dfd8056a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/div[2]/div/div/div/div[3]</value>
      <webElementGuid>9d56df4c-6f84-48a1-9139-e2a3b85a0a58</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Create a text story' or . = 'Create a text story')]</value>
      <webElementGuid>99d15762-ff37-4bf1-b27f-d8c94926c9b8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
