<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Ludo Club</name>
   <tag></tag>
   <elementGuidId>2f937e23-0f9f-47c3-ab36-03c2a486be74</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='mount_0_0_Rb']/div/div/div/div[3]/div/div/div/div/div[2]/div/div/div/div/div/div[5]/div[2]/div/div/div[2]/div/div/div/div/div/div/div/div/div/div/a/div/div/div[2]/div/div[3]/span/span/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.x5yr21d > div > div > div > div > div > div > a.x1i10hfl.x1qjc9v5.xjbqb8w.xjqpnuy.xa49m3k.xqeqjp1.x2hbi6w.x13fuv20.xu3j5b3.x1q0q8m5.x26u7qi.x972fbf.xcfux6l.x1qhh985.xm0m39n.x9f619.x1ypdohk.xdl72j9.x2lah0s.xe8uvvx.xdj266r.x11i5rnm.xat24cr.x1mh8g0r.x2lwn1j.xeuugli.xexx8yu.x4uap5.x18d9i69.xkhd6sd.x1n2onr6.x16tdsg8.x1hl2dhg.xggy1nq.x1ja2u2z.x1t137rt.x1q0g3np.x87ps6o.x1lku1pv.x1rg5ohu.x1a2a7pz.x1qpq9i9.xdney7k.xu5ydu1.xt3gfkd.xh8yej3 > div.x78zum5.x1n2onr6.xh8yej3 > div.x9f619.x1n2onr6.x1ja2u2z.x1jx94hy.x1qpq9i9.xdney7k.xu5ydu1.xt3gfkd.xh8yej3.x6ikm8r.x10wlt62.xquyuld > div.xh8yej3 > div.x1n2onr6 > div.xz9dl7a.x1sxyh0.xsag5q8.xurb0ha.xgqk73l > span.x4k7w5x.x1h91t0o.x1h9r5lt.x1jfb8zj.xv2umb2.x1beo9mf.xaigb6o.x12ejxvf.x3igimt.xarpa2k.xedcshv.x1lytzrv.x1t2pt76.x7ja8zs.x1qrby5j > span.x193iq5w.xeuugli.x13faqbe.x1vvkbs.x1xmvt09.x1lliihq.x1s928wv.xhkezso.x1gmr53x.x1cpjm7i.x1fgarty.x1943h6x.xudqn12.x3x7a5m.x1lkfr7t.x1lbecb7.x1s688f.x17z8epw > span.x1lliihq.x6ikm8r.x10wlt62.x1n2onr6.xlyipyv.xuxw1ft.x1j85h84</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:label=&quot;Top picks for you&quot;i >> internal:role=link[name=&quot;game image Ludo Club Board&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>998158cb-6344-49ea-b94d-0f7f22ce643a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>x1lliihq x6ikm8r x10wlt62 x1n2onr6 xlyipyv xuxw1ft x1j85h84</value>
      <webElementGuid>907c4a04-376a-45ee-9ce9-78dcdef90208</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Ludo Club</value>
      <webElementGuid>c32f4669-21ae-49b1-b174-b134f7c54225</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mount_0_0_Rb&quot;)/div[1]/div[1]/div[@class=&quot;x9f619 x1n2onr6 x1ja2u2z&quot;]/div[@class=&quot;x9f619 x1n2onr6 x1ja2u2z&quot;]/div[@class=&quot;x78zum5 xdt5ytf x1n2onr6 x1ja2u2z&quot;]/div[@class=&quot;x78zum5 xdt5ytf x1n2onr6 xat3117 xxzkxad&quot;]/div[@class=&quot;x78zum5 xdt5ytf x1t2pt76 x1n2onr6 x1ja2u2z x10cihs4&quot;]/div[@class=&quot;x9f619 x1ja2u2z x78zum5 x1q0g3np x1iyjqo2 x1t2pt76 x1n2onr6 xvrxa7q x1nhjfyr&quot;]/div[@class=&quot;x9f619 x2lah0s x1n2onr6 x78zum5 x1iyjqo2 x1t2pt76 x1lspesw&quot;]/div[@class=&quot;x78zum5 xdt5ytf x1iyjqo2 x1t2pt76 xeuugli x1n2onr6 x1ja2u2z&quot;]/div[@class=&quot;x1lliihq x193iq5w&quot;]/div[1]/div[@class=&quot;x78zum5 xdt5ytf&quot;]/div[@class=&quot;xamitd3 xxms4ga xgqk73l&quot;]/div[5]/div[@class=&quot;xexx8yu x1vjfegm&quot;]/div[1]/div[@class=&quot;x9f619 x1n2onr6 x1ja2u2z&quot;]/div[@class=&quot;x9f619 x1n2onr6 x1ja2u2z x1wsgfga x9otpla xwib8y2 x1y1aw1k&quot;]/div[@class=&quot;xb57i2i x1q594ok x5lxg6s x78zum5 xdt5ytf x10wlt62 x1n2onr6 x1ja2u2z x1pq812k xfk6m8 x1yqm8si xjx87ck xw2csxc x7p5m3t x9f619 xat24cr xwib8y2 x1y1aw1k x1rohswg xhfbhpw&quot;]/div[@class=&quot;x78zum5 x1iyjqo2 x1n2onr6 x1q0g3np&quot;]/div[@class=&quot;x1c4vz4f x2lah0s xeuugli x1bhewko x1emribx xnqqybz&quot;]/div[@class=&quot;x5yr21d&quot;]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/a[@class=&quot;x1i10hfl x1qjc9v5 xjbqb8w xjqpnuy xa49m3k xqeqjp1 x2hbi6w x13fuv20 xu3j5b3 x1q0q8m5 x26u7qi x972fbf xcfux6l x1qhh985 xm0m39n x9f619 x1ypdohk xdl72j9 x2lah0s xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r x2lwn1j xeuugli xexx8yu x4uap5 x18d9i69 xkhd6sd x1n2onr6 x16tdsg8 x1hl2dhg xggy1nq x1ja2u2z x1t137rt x1q0g3np x87ps6o x1lku1pv x1rg5ohu x1a2a7pz x1qpq9i9 xdney7k xu5ydu1 xt3gfkd xh8yej3&quot;]/div[@class=&quot;x78zum5 x1n2onr6 xh8yej3&quot;]/div[@class=&quot;x9f619 x1n2onr6 x1ja2u2z x1jx94hy x1qpq9i9 xdney7k xu5ydu1 xt3gfkd xh8yej3 x6ikm8r x10wlt62 xquyuld&quot;]/div[@class=&quot;xh8yej3&quot;]/div[@class=&quot;x1n2onr6&quot;]/div[@class=&quot;xz9dl7a x1sxyh0 xsag5q8 xurb0ha xgqk73l&quot;]/span[@class=&quot;x4k7w5x x1h91t0o x1h9r5lt x1jfb8zj xv2umb2 x1beo9mf xaigb6o x12ejxvf x3igimt xarpa2k xedcshv x1lytzrv x1t2pt76 x7ja8zs x1qrby5j&quot;]/span[@class=&quot;x193iq5w xeuugli x13faqbe x1vvkbs x1xmvt09 x1lliihq x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x xudqn12 x3x7a5m x1lkfr7t x1lbecb7 x1s688f x17z8epw&quot;]/span[@class=&quot;x1lliihq x6ikm8r x10wlt62 x1n2onr6 xlyipyv xuxw1ft x1j85h84&quot;]</value>
      <webElementGuid>d5fa9270-c7e2-4e05-9009-85b182eab840</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='mount_0_0_Rb']/div/div/div/div[3]/div/div/div/div/div[2]/div/div/div/div/div/div[5]/div[2]/div/div/div[2]/div/div/div/div/div/div/div/div/div/div/a/div/div/div[2]/div/div[3]/span/span/span</value>
      <webElementGuid>6361ca0a-a1f7-4a6a-afdc-1b7c46e30221</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Top picks for you'])[1]/following::span[3]</value>
      <webElementGuid>a070ccc8-b1db-40c1-8783-bfa8c25284a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mahjong Social'])[1]/following::span[8]</value>
      <webElementGuid>e8975115-b712-4360-8121-ac383af2282a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Board'])[2]/preceding::span[1]</value>
      <webElementGuid>90850eed-b539-4f9c-a1f7-e2e3680efb1a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Teen Patti game'])[1]/preceding::span[4]</value>
      <webElementGuid>8da6917c-9c79-4c2b-bddc-617fd79d6757</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Ludo Club']/parent::*</value>
      <webElementGuid>b89bab30-5242-4ce8-82d4-4bb8f7f3bb43</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div[2]/div/div/div/div/div/div/div/div/div/div/a/div/div/div[2]/div/div[3]/span/span/span</value>
      <webElementGuid>bca5cf86-9612-4834-9afb-0dab66a6b79e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Ludo Club' or . = 'Ludo Club')]</value>
      <webElementGuid>94b36ba5-a7af-4eb3-a1f2-db73757a3481</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
