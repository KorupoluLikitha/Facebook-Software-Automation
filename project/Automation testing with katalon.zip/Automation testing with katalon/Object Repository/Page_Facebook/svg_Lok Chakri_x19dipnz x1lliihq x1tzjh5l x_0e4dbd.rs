<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_Lok Chakri_x19dipnz x1lliihq x1tzjh5l x_0e4dbd</name>
   <tag></tag>
   <elementGuidId>47ffda21-21f4-4388-9d5d-58f02c004b18</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Lok Chakri'])[1]/following::*[name()='svg'][5]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:label=&quot;Close chat&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>dc04e7f1-e795-40ee-b705-57a50cfb6afd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>viewBox</name>
      <type>Main</type>
      <value>0 0 12 13</value>
      <webElementGuid>c8d69d71-99c0-47c2-bc4b-0592966044ee</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>width</name>
      <type>Main</type>
      <value>20</value>
      <webElementGuid>9cb09b58-eede-4dc2-84e7-1f11f64d98ad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>height</name>
      <type>Main</type>
      <value>20</value>
      <webElementGuid>40bd5247-0081-49c7-996b-2cb420184aba</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>fill</name>
      <type>Main</type>
      <value>currentColor</value>
      <webElementGuid>1ede91fc-11ea-41f5-8a40-dcd067454f86</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>x19dipnz x1lliihq x1tzjh5l x1k90msu x2h7rmj x1qfuztq</value>
      <webElementGuid>9122b303-7d25-4aab-8720-761307c8c97e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mount_0_0_Rt&quot;)/div[1]/div[1]/div[@class=&quot;x9f619 x1n2onr6 x1ja2u2z&quot;]/div[5]/div[@class=&quot;x1ey2m1c xds687c xixxii4&quot;]/div[@class=&quot;xuk3077 x78zum5 xc8icb0&quot;]/div[@class=&quot;x1ey2m1c x78zum5 x164qtfw xixxii4 x1vjfegm&quot;]/div[1]/div[1]/div[1]/div[@class=&quot;x9f619 x1n2onr6 x1ja2u2z __fb-light-mode x78zum5 xdt5ytf x1iyjqo2 xs83m0k x193iq5w&quot;]/div[@class=&quot;x1uvtmcs x4k7w5x x1h91t0o x1beo9mf xaigb6o x12ejxvf x3igimt xarpa2k xedcshv x1lytzrv x1t2pt76 x7ja8zs x1n2onr6 x1qrby5j x1jfb8zj&quot;]/div[@class=&quot;x5yr21d x1uvtmcs&quot;]/div[@class=&quot;xcrg951 xgqcy7u x1lq5wgf x78zum5 xdt5ytf x6prxxf xvq8zen x17adc0v xi55695 x1rgmuzj x85a59c xbbk1sx x1eqhsl0&quot;]/div[1]/div[@class=&quot;x6s0dn4 xfpmyvw xgqcy7u x1lq5wgf x78zum5 x2lah0s x10w6t97 x1qughib x6ikm8r x10wlt62 x1y1aw1k x1sxyh0 xwib8y2 xurb0ha x1n2onr6 xhtitgo x7m3og9&quot;]/div[@class=&quot;x6s0dn4 x78zum5 xcud41i&quot;]/span[@class=&quot;x4k7w5x x1h91t0o x1h9r5lt x1jfb8zj xv2umb2 x1beo9mf xaigb6o x12ejxvf x3igimt xarpa2k xedcshv x1lytzrv x1t2pt76 x7ja8zs x1qrby5j&quot;]/div[@class=&quot;x9f619 x1n2onr6 x1ja2u2z __fb-light-mode&quot;]/div[@class=&quot;x1i10hfl xjqpnuy xa49m3k xqeqjp1 x2hbi6w x13fuv20 xu3j5b3 x1q0q8m5 x26u7qi x1ypdohk xdl72j9 x2lah0s xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r x2lwn1j xeuugli x16tdsg8 x1hl2dhg xggy1nq x1ja2u2z x1t137rt x1q0g3np x87ps6o x1lku1pv x1a2a7pz x6s0dn4 xzolkzo x12go9s9 x1rnf11y xprq8jg x972fbf xcfux6l x1qhh985 xm0m39n x9f619 x78zum5 xl56j7k xexx8yu x4uap5 x18d9i69 xkhd6sd x1n2onr6 x1fgtraw xgd8bvy xjbqb8w&quot;]/svg[@class=&quot;x19dipnz x1lliihq x1tzjh5l x1k90msu x2h7rmj x1qfuztq&quot;]</value>
      <webElementGuid>ab01f6e6-af95-4a3a-a45c-6403ee07f394</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lok Chakri'])[1]/following::*[name()='svg'][5]</value>
      <webElementGuid>5c218bf2-00f5-4fd5-8d98-cbe8ed521a7b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Visit Help Center'])[1]/following::*[name()='svg'][5]</value>
      <webElementGuid>6b43bcc2-ea22-44be-ac22-ae43e22a8c27</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lok Chakri'])[2]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>ce3e021d-0c46-48be-81aa-e277244b9d22</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
