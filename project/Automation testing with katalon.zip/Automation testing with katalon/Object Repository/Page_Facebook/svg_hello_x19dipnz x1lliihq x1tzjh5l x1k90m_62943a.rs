<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_hello_x19dipnz x1lliihq x1tzjh5l x1k90m_62943a</name>
   <tag></tag>
   <elementGuidId>3bbec5b2-2794-44a5-a9ae-3eb4c6335ebe</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='annaya'])[1]/following::*[name()='svg'][2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.html-div.xdj266r.x11i5rnm.xat24cr.x1mh8g0r.xexx8yu.x4uap5.x18d9i69.xkhd6sd.x1c4vz4f.x2lah0s > span.x4k7w5x.x1h91t0o.x1h9r5lt.x1jfb8zj.xv2umb2.x1beo9mf.xaigb6o.x12ejxvf.x3igimt.xarpa2k.xedcshv.x1lytzrv.x1t2pt76.x7ja8zs.x1qrby5j > div.x9f619.x1n2onr6.x1ja2u2z.__fb-light-mode > div.x1i10hfl.xjqpnuy.xa49m3k.xqeqjp1.x2hbi6w.x13fuv20.xu3j5b3.x1q0q8m5.x26u7qi.x1ypdohk.xdl72j9.x2lah0s.xe8uvvx.xdj266r.x11i5rnm.xat24cr.x1mh8g0r.x2lwn1j.xeuugli.x16tdsg8.x1hl2dhg.xggy1nq.x1ja2u2z.x1t137rt.x1q0g3np.x87ps6o.x1lku1pv.x1a2a7pz.x6s0dn4.xzolkzo.x12go9s9.x1rnf11y.xprq8jg.x972fbf.xcfux6l.x1qhh985.xm0m39n.x9f619.x78zum5.xl56j7k.xexx8yu.x4uap5.x18d9i69.xkhd6sd.x1n2onr6.xc9qbxq.x14qfxbe.xjbqb8w > svg.x19dipnz.x1lliihq.x1tzjh5l.x1k90msu.x2h7rmj.x1qfuztq</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:label=&quot;Press enter to send&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>d7c1d424-d2f5-440e-a298-239eae7b1cf3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>viewBox</name>
      <type>Main</type>
      <value>0 0 12 13</value>
      <webElementGuid>54248103-6964-41f9-bbde-6f162efb65fc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>width</name>
      <type>Main</type>
      <value>20</value>
      <webElementGuid>f074e30a-b667-4c3a-8429-1664a1a7bae0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>height</name>
      <type>Main</type>
      <value>20</value>
      <webElementGuid>9dcd1e48-654b-429f-a0bd-5d3c3b548d3a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>fill</name>
      <type>Main</type>
      <value>currentColor</value>
      <webElementGuid>31629fb9-08ee-40b4-9180-f54204dad888</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>x19dipnz x1lliihq x1tzjh5l x1k90msu x2h7rmj x1qfuztq</value>
      <webElementGuid>781f4f54-fc57-4a6b-ba65-29d92145469d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mount_0_0_Rt&quot;)/div[1]/div[1]/div[@class=&quot;x9f619 x1n2onr6 x1ja2u2z&quot;]/div[5]/div[@class=&quot;x1ey2m1c xds687c xixxii4&quot;]/div[@class=&quot;xuk3077 x78zum5 xc8icb0&quot;]/div[@class=&quot;x1ey2m1c x78zum5 x164qtfw xixxii4 x1vjfegm&quot;]/div[1]/div[1]/div[1]/div[@class=&quot;x9f619 x1n2onr6 x1ja2u2z __fb-light-mode x78zum5 xdt5ytf x1iyjqo2 xs83m0k x193iq5w&quot;]/div[@class=&quot;x1uvtmcs x4k7w5x x1h91t0o x1beo9mf xaigb6o x12ejxvf x3igimt xarpa2k xedcshv x1lytzrv x1t2pt76 x7ja8zs x1n2onr6 x1qrby5j x1jfb8zj&quot;]/div[@class=&quot;x5yr21d x1uvtmcs&quot;]/div[@class=&quot;xcrg951 xgqcy7u x1lq5wgf x78zum5 xdt5ytf x6prxxf xvq8zen x17adc0v xi55695 x1rgmuzj x85a59c xbbk1sx x1eqhsl0&quot;]/div[@class=&quot;x78zum5 xdt5ytf x1iyjqo2 x193iq5w x2lwn1j x1n2onr6&quot;]/div[2]/div[@class=&quot;html-div xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd xt5xv9l x6wvzqs xpqajaz x78zum5 xdt5ytf x1c4vz4f xs83m0k x13qp9f6&quot;]/div[@class=&quot;html-div xdj266r x11i5rnm xat24cr x1mh8g0r xpqajaz x9f619 x78zum5 x1iyjqo2 xs83m0k x1n2onr6 xh8yej3 x1e558r4 x150jy0e xz9dl7a xsag5q8&quot;]/div[@class=&quot;html-div xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x1c4vz4f x2lah0s&quot;]/span[@class=&quot;x4k7w5x x1h91t0o x1h9r5lt x1jfb8zj xv2umb2 x1beo9mf xaigb6o x12ejxvf x3igimt xarpa2k xedcshv x1lytzrv x1t2pt76 x7ja8zs x1qrby5j&quot;]/div[@class=&quot;x9f619 x1n2onr6 x1ja2u2z __fb-light-mode&quot;]/div[@class=&quot;x1i10hfl xjqpnuy xa49m3k xqeqjp1 x2hbi6w x13fuv20 xu3j5b3 x1q0q8m5 x26u7qi x1ypdohk xdl72j9 x2lah0s xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r x2lwn1j xeuugli x16tdsg8 x1hl2dhg xggy1nq x1ja2u2z x1t137rt x1q0g3np x87ps6o x1lku1pv x1a2a7pz x6s0dn4 xzolkzo x12go9s9 x1rnf11y xprq8jg x972fbf xcfux6l x1qhh985 xm0m39n x9f619 x78zum5 xl56j7k xexx8yu x4uap5 x18d9i69 xkhd6sd x1n2onr6 xc9qbxq x14qfxbe xjbqb8w&quot;]/svg[@class=&quot;x19dipnz x1lliihq x1tzjh5l x1k90msu x2h7rmj x1qfuztq&quot;]</value>
      <webElementGuid>100954e0-1b2d-4a91-a17b-949b7ec262c8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='annaya'])[1]/following::*[name()='svg'][2]</value>
      <webElementGuid>5a792025-4a8d-48b0-b977-f16061a9f163</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enter'])[1]/following::*[name()='svg'][3]</value>
      <webElementGuid>6f3124a9-7cfd-4e9d-a780-eebff3530725</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Press enter to send'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>c840e1a9-9ead-4dc1-a7da-ed64e0218fa0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='hello'])[1]/following::*[name()='svg'][2]</value>
      <webElementGuid>89443581-022d-467b-b537-2da9a4c67839</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='You are now connected on Messenger'])[1]/following::*[name()='svg'][3]</value>
      <webElementGuid>e6042f81-64b9-4132-a148-a4ba1e640c89</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
